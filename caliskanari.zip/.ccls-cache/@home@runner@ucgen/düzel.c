#include <stdio.h>

int main() {

  int a, b; 
  printf("a değerini giriniz: ");
  scanf("%d", &a);  

  printf("b değerini giriniz: ");
  scanf("%d", &b);  

  if (a % b ==0){
    printf("kalan sıfır");
    } 
  return 0;
} 