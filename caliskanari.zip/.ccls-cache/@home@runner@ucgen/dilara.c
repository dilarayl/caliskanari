#include <stdio.h>

int main() {
  
  int a, b ; 
  printf( "a değerini giriniz:");
  printf( "b değerini giriniz:");
scanf("%d", &a, &b);

  if(a<b) {
printf("a-b\n");
} else (a>b) {
  printf("b-a\n");
    } 
  return 0;
  }
    
