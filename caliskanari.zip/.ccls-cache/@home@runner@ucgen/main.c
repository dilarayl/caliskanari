
#include <stdio.h>
#include <stdlib.h>
#include <time.h>

#define ROWS 10
#define COLS 10
#define FLOWERS 5
#define WASPS 3
#define MAX_HONEY 5 // Kazanmak için gereken bal miktarı

char map[ROWS][COLS]; // Oyun haritası
typedef struct {
    int x, y;
} Position;

Position bee; // Arının konumu
Position flowers[FLOWERS]; // Çiçeklerin konumu
Position wasps[WASPS]; // Eşek arılarının konumu
int collectedFlowers = 0; // Toplanan çiçek sayısı
int honey = 0; // Arının sahip olduğu bal miktarı

// Haritayı temizle
void clearMap() {
    for (int i = 0; i < ROWS; i++) {
        for (int j = 0; j < COLS; j++) {
            map[i][j] = '.'; // Boş alanları "." ile doldurma
        }
    }
}

// Haritaya yerleşim
void updateMap() {
    clearMap();

    // Çiçekleri ekle
    for (int i = 0; i < FLOWERS; i++) {
        map[flowers[i].x][flowers[i].y] = '*';
    }

    // Eşek arılarını ekleme
    for (int i = 0; i < WASPS; i++) {
        map[wasps[i].x][wasps[i].y] = 'X';
    }

    // Arıyı ekleme
    map[bee.x][bee.y] = 'A';
}

// Harita çizimi
void drawMap() {
    system("clear"); // Ekranı temizle 

    for (int i = 0; i < ROWS; i++) {
        for (int j = 0; j < COLS; j++) {
            if (map[i][j] == 'A') {
                printf("\033[33mA\033[0m "); // Sarı renkli arı
            } else if (map[i][j] == '*') {
                printf("\033[32m*\033[0m "); // Yeşil çiçek
            } else if (map[i][j] == 'X') {
                printf("\033[31mX\033[0m "); // Kırmızı eşek arısı
            } else {
                printf("%c ", map[i][j]);
            }
        }
        printf("\n");
    }
    printf("Toplanan Çiçekler: %d | Bal: %d\n", collectedFlowers, honey);
}

// Rastgele pozisyon üretici
Position randomPosition() {
    Position pos;
    pos.x = rand() % ROWS;
    pos.y = rand() % COLS;
    return pos;
}

// Çiçekleri yerleştir
void placeFlowers() {
    for (int i = 0; i < FLOWERS; i++) {
        flowers[i] = randomPosition();
    }
}

// Eşek arılarını yerleştir
void placeWasps() {
    for (int i = 0; i < WASPS; i++) {
        wasps[i] = randomPosition();
    }
}

// Arının hareketi
void moveBee(char direction) {
    direction = tolower(direction); // Büyük harfleri küçük harfe çevir
    switch (direction) {
        case 'w':
            if (bee.x > 0) bee.x--;
            break;
        case 's':
            if (bee.x < ROWS - 1) bee.x++;
            break;
        case 'a':
            if (bee.y > 0) bee.y--;
            break;
        case 'd':
            if (bee.y < COLS - 1) bee.y++;
            break;
        default:
            printf("Geçersiz giriş!\n");
    }
}

// Çiçek topla
void collectFlowers() {
    for (int i = 0; i < FLOWERS; i++) {
        if (bee.x == flowers[i].x && bee.y == flowers[i].y) {
            collectedFlowers++;
            flowers[i] = randomPosition();
            printf("Çiçek toplandı! Toplanan çiçekler: %d\n", collectedFlowers);

            if (collectedFlowers >= 5) {
                honey++;
                collectedFlowers = 0;
                printf("5 çiçek toplandı! Yeni bir bal yapıldı. Toplam bal: %d\n", honey);
            }
            break;
        }
    }
}

// Eşek arılarının hareketi
void moveWasps() {
    for (int i = 0; i < WASPS; i++) {
        int direction = rand() % 4; // Rastgele bir yön seç
        switch (direction) {
            case 0: // Yukarı
                if (wasps[i].x > 0) wasps[i].x--;
                break;
            case 1: // Aşağı
                if (wasps[i].x < ROWS - 1) wasps[i].x++;
                break;
            case 2: // Sol
                if (wasps[i].y > 0) wasps[i].y--;
                break;
            case 3: // Sağ
                if (wasps[i].y < COLS - 1) wasps[i].y++;
                break;
        }
    }
}

// Eşek arısı kontrolü
int checkWasps() {
    for (int i = 0; i < WASPS; i++) {
        if (bee.x == wasps[i].x && bee.y == wasps[i].y) {
            printf("Eşek arısı tarafından yakalandın! Oyun bitti.\n");
            return 1;
        }
    }
    return 0;
}

// Kazanma durumu kontrolü
int checkWin() {
    if (honey >= MAX_HONEY) {
        printf("Tebrikler! 5 bal yaparak oyunu kazandınız!\n");
        return 1;
    }
    return 0;
}

int main() {
    srand(time(NULL));
    bee = randomPosition(); // Arının başlangıç pozisyonu
    placeFlowers(); // Çiçekleri yerleştir
    placeWasps(); // Eşek arılarını yerleştir

    while (1) {
        updateMap();
        drawMap();
        printf("Hareket (w/a/s/d): ");
        char move;
        scanf(" %c", &move);
        moveBee(move);
        moveWasps(); // Eşek arılarını hareket ettirir
        collectFlowers();
        if (checkWasps() || checkWin()) {
            break;
        }
    }

    return 0;
}
