#include <stdio.h>

int main() {
    int sayi1, sayi2, sonuc;

    // Kullanıcıdan iki sayı alma
    printf("Birinci sayıyı girin: ");
    scanf("%d", &sayi1);
    printf("İkinci sayıyı girin: ");
    scanf("%d", &sayi2);

    // Çarpma işlemi
    sonuc = sayi1 * sayi2;

    // Sonucu ekrana yazdırma
    printf("Sonuç: %d\n", sonuc);

    return 0;
}