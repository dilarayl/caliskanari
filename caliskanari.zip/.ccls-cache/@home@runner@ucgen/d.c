#include <stdio.h>

int main() {
    char operator;
    double num1, num2, result;

    // Kullanıcıdan işlem türünü ve sayıları alıyoruz
    printf("İşlem türünü giriniz (+, -, *, /): ");
    scanf(" %c", &operator);

    printf("İlk sayıyı giriniz: ");
    scanf("%lf", &num1);

    printf("İkinci sayıyı giriniz: ");
    scanf("%lf", &num2);

    // İşlem türüne göre farklı hesaplamalar yapıyoruz
    switch (operator) {
        case '+':
            result = num1 + num2;
            printf("%.2lf + %.2lf = %.2lf\n", num1, num2, result);
            break;
        case '-':
            result = num1 - num2;
            printf("%.2lf - %.2lf = %.2lf\n", num1, num2, result);
            break;
        case '*':
            result = num1 * num2;
            printf("%.2lf * %.2lf = %.2lf\n", num1, num2, result);
            break;
        case '/':
            if (num2 != 0) {
                result = num1 / num2;
                printf("%.2lf / %.2lf = %.2lf\n", num1, num2, result);
            } else {
                printf("Hata: Sıfıra bölme işlemi yapılamaz!\n");
            }
            break;
        default:
            printf("Geçersiz işlem türü.\n");
            break;
    }

    return 0;
}