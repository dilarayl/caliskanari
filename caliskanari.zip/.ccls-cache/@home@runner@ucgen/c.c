#include <stdio.h>
#include <stdlib.h>
#include <time.h>

#define ROWS 10
#define COLS 10
#define FLOWERS 5
#define WASPS 3

char map[ROWS][COLS]; // Oyun haritası
typedef struct {
    int x, y;
} Position;

Position bee; // Arının pozisyonu
Position flowers[FLOWERS]; // Çiçeklerin pozisyonu
Position wasps[WASPS]; // Eşek arılarının pozisyonu
int honey = 0; // Arının bal miktarı

// Haritayı temizle
void clearMap() {
    for (int i = 0; i < ROWS; i++) {
        for (int j = 0; j < COLS; j++) {
            map[i][j] = '.'; // Boş alanları "." ile doldur
        }
    }
}

// Harita çizimi
void drawMap() {
    system("clear"); // Ekranı temizle (Windows'ta "cls" kullan)

    for (int i = 0; i < ROWS; i++) {
        for (int j = 0; j < COLS; j++) {
            if (bee.x == i && bee.y == j) {
                printf("\033[33mA\033[0m "); // Sarı renkli arı
            } else {
                int isFlower = 0, isWasp = 0;

                for (int k = 0; k < FLOWERS; k++) {
                    if (flowers[k].x == i && flowers[k].y == j) {
                        printf("\033[32m*\033[0m "); // Yeşil çiçek
                        isFlower = 1;
                        break;
                    }
                }

                if (!isFlower) {
                    for (int k = 0; k < WASPS; k++) {
                        if (wasps[k].x == i && wasps[k].y == j) {
                            printf("\033[31mX\033[0m "); // Kırmızı eşek arısı
                            isWasp = 1;
                            break;
                        }
                    }
                }

                if (!isFlower && !isWasp) {
                    printf("%c ", map[i][j]);
                }
            }
        }
        printf("\n");
    }
    printf("Bal: %d\n", honey);
}

// Rastgele pozisyon üretici
Position randomPosition() {
    Position pos;
    pos.x = rand() % ROWS;
    pos.y = rand() % COLS;
    return pos;
}

// Çiçekleri yerleştir
void placeFlowers() {
    for (int i = 0; i < FLOWERS; i++) {
        flowers[i] = randomPosition();
    }
}

// Eşek arılarını yerleştir
void placeWasps() {
    for (int i = 0; i < WASPS; i++) {
        wasps[i] = randomPosition();
    }
}

// Arının hareketi
void moveBee(char direction) {
    switch (direction) {
        case 'w':
            if (bee.x > 0) bee.x--;
            break;
        case 's':
            if (bee.x < ROWS - 1) bee.x++;
            break;
        case 'a':
            if (bee.y > 0) bee.y--;
            break;
        case 'd':
            if (bee.y < COLS - 1) bee.y++;
            break;
        default:
            printf("Geçersiz giriş!\n");
    }
}

// Çiçek topla
void collectFlowers() {
    for (int i = 0; i < FLOWERS; i++) {
        if (bee.x == flowers[i].x && bee.y == flowers[i].y) {
            honey++;
            flowers[i] = randomPosition();
            printf("Çiçek toplandı! Bal: %d\n", honey);
            break;
        }
    }
}

// Eşek arısı kontrolü
int checkWasps() {
    for (int i = 0; i < WASPS; i++) {
        if (bee.x == wasps[i].x && bee.y == wasps[i].y) {
            printf("Eşek arısı tarafından yakalandın! Oyun bitti.\n");
            return 1;
        }
    }
    return 0;
}

int main() {
    srand(time(NULL));
    bee = randomPosition(); // Arının başlangıç pozisyonu
    placeFlowers(); // Çiçekleri yerleştir
    placeWasps(); // Eşek arılarını yerleştir

    while (1) {
        drawMap();
        printf("Hareket (w/a/s/d): ");
        char move;
        scanf(" %c", &move);
        moveBee(move);
        collectFlowers();
        if (checkWasps()) {
            break;
        }
    }

    return 0;
}
